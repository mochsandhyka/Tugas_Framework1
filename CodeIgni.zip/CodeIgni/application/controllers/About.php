<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function index()
	{
		$data = array(
			'nama' => "Mochamad Sandhyka Wahyudi",
			'nim' => "1541180191",
			'alamat' => "Malang",
			'no_telp' => "081333220134", 
			);
		$this->load->view('about',$data);		
	}

}

/* End of file About.php */
/* Location: ./application/controllers/About.php */
